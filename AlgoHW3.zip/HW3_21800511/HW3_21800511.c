//
//  main.c
//  KCProblem
//
//  Created by 이민재 on 10/04/2020.
//  Copyright © 2020 yi. All rights reserved.
//

#include <stdio.h>

int KCR(int n, int k)
{
    if( (n>=k) & (k==0))
        return 1;
    else if( (n==0) & (k>0) )
        return 0;
    else if(n==k)
        return 1;
    else{
        return KCR(n-1,k-1) + KCR(n-1, k);
    }
}

int KCDP(int n, int k,int S[][100])
{
    if(S[n][k]!=-1)
        return S[n][k];
    else if( (n>=k) & (k==0))
        S[n][k] = 1;
    else if( (n==0) & (k>0) )
        S[n][k] = 0;
    else if(n==k)
        S[n][k] = 1;
    else{
        S[n][k] = KCDP(n-1,k-1,S) + KCDP(n-1,k,S);
    }
    return S[n][k];
}

int main(int argc, const char * argv[]) {
    int n , k;
    printf("This is k-combination solver\n");
    printf("Please enter n and k for C(n,k) : ");
    scanf("%d %d",&n,&k);
    if((n < k)|(n<0)|(k<0))
        printf("wrong input\n");
    else{
        //recursion
        printf("C(%d,%d) = %d\n",n,k,KCR(n,k));
        //Dynmamic Programming
        int S[100][100];
        for(int i = 0; i <= n; i++)
            for(int j = 0; j <=k; j++)
            {
                S[i][j] = -1;
            }
        printf("C(%d,%d) = %d\n",n,k,KCDP(n,k,S));
    }
}
